export class Usuario {
    id: number = 0;
    username: string = '';
    firstName: string= '';
    lastName: string= '';
    role: string= '';
    token?: string;
}