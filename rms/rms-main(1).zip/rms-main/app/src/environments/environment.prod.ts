export const environment = {
  production: true,
  api: 'http://localhost:3000',
  token: {
    app: '4f98e5d6-9f17-4b64-a6ba-5c245bac3bef',
    //api: 'https://sau.aps.gob.bo/jwt/api/v2/token',
    //user: 'https://sau.aps.gob.bo/jwt/api/v2/usuarios',
    api: 'http://192.168.57.146:97/jwt/api/v2/token',
    user: 'http://192.168.57.146:97/jwt/api/v2/usuarios'
    /*api: 'http://localhost:3000/token',
    user: 'http://localhost:3000/token',*/
  }
};
