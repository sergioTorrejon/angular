
export enum Roles {
    Administrador = 'administrador',
    OperadorFuncionarios = 'operador_funcionarios',
    AprobadorFuncionarios = 'aprobador_funcionarios'
}
