//STATUS OPTIONS
    //TODO: REVISAR SI SE PUEDE MEJORAR interfaces
export const globalPipe = {
    transform: true,
    whitelist: true,
    //forbidNonWhitelisted: true,
    transformOptions: {
        enableImplicitConversion: true,
    },
}