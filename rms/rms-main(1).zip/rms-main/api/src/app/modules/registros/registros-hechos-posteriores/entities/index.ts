export * from './registros-hechos-posteriores.entity';
