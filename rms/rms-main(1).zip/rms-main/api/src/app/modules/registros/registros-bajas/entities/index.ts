export * from './registros-bajas.entity';
