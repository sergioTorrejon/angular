export * from './registros-hechos-posteriores-create.dto';
export * from './registros-hechos-posteriores-update.dto';

