export * from './registros-funcionarios-create.dto';
export * from './registros-funcionarios-update.dto';

