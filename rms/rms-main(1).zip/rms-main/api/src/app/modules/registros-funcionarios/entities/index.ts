export * from './registros-funcionarios.entity';
