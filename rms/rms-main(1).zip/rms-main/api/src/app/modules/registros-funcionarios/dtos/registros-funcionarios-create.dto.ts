import {
  IsString,
  MaxLength,
} from 'class-validator';

import { ApiProperty } from '@nestjs/swagger';

import { Empresa } from '../../empresa/entities';
import { PersonaNatural } from '../../persona-natural/entities';
import { BaseDto } from 'src/core/dtos/BaseDto';

export class RegistrosFuncionariosCreateDto extends BaseDto{
  
  @ApiProperty()
  @IsString()
  personaNatural: PersonaNatural;

  @ApiProperty()
  @IsString()
  empresa: Empresa;

  @ApiProperty()
  @IsString()
  @MaxLength(50)
  cargo: string;

  @ApiProperty()
  @IsString()
  @MaxLength(20)
  estado: string;

}
