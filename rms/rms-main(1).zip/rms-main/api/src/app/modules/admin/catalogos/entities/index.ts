export * from './catalogos.entity';
