export * from './categoria-registro.entity';
