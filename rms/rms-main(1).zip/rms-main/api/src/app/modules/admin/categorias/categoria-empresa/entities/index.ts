export * from './categoria-empresa.entity';
