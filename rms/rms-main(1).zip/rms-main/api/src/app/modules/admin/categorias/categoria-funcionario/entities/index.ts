export * from './categoria-funcionario.entity';
