export * from './categoria-persona-create.dto';
export * from './categoria-persona-update.dto';

