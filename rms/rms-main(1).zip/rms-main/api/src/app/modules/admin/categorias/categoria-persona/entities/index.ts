export * from './categoria-persona.entity';
