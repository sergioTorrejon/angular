export * from './persona-natural.entity';
