export * from './persona-natural-create.dto';
export * from './persona-natural-update.dto';

