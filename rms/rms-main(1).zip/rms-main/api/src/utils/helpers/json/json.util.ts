export const JsonToStringfi = (_json:any) =>{
    return JSON.stringify(_json)
}